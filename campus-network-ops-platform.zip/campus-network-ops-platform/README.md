# 校园网络运维与故障管理平台

一个面向校园网络运维场景的教学/课程设计项目，定位为“软件工程专业 + 通信网络工程师”求职作品。项目模拟网络故障受理、工单处理、网络设备与 IP 资源管理、基础连通性检测和运维数据统计等流程。

> 说明：这是用于学习、课程设计和简历展示的模拟系统，不接入真实校园网设备，也不代表实际运营商生产系统。

## 技术栈

- 后端：Java 17+ / Spring Boot 3 / Spring Web / Spring Data JPA / MySQL
- 前端：Vue 3 / Vite / Vue Router / 原生 CSS
- 工具：Git / Maven / Postman
- 部署：可运行在 Linux + Nginx + MySQL 环境

## 项目结构

```text
campus-network-ops-platform/
├─ backend/                 # Spring Boot 后端
├─ frontend/                # Vue 3 前端
├─ database/                # MySQL 建库和初始化数据脚本
├─ docs/                    # 项目文档、接口、测试、面试说明
└─ README.md
```

## 快速启动

### 1. 初始化数据库

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p campus_network_ops < database/seed.sql
```

### 2. 配置数据库

编辑 `backend/src/main/resources/application.yml`，修改 `username/password`。

### 3. 启动后端

```bash
cd backend
mvn spring-boot:run
```

后端默认：`http://localhost:8080`

### 4. 启动前端

```bash
cd frontend
npm install
npm run dev
```

前端默认：`http://localhost:5173`

## 默认账号

- admin / 123456
- operator / 123456
- student / 123456

## 当前版本说明

- 工单流转：待处理 → 处理中 → 待验证 → 已完成
- 设备管理：路由器、交换机、无线 AP
- IP 资源管理：网段、IP 使用状态、MAC、归属
- 连通性检测：为教学演示而设计的模拟检测，不执行系统 Ping
- 看板：设备及故障工单统计

## 面试与简历提示

请只陈述自己真正完成并理解的内容。尤其不要把模拟的连通性检测描述为已经接入真实校园网、运营商网络或真实网管平台。
