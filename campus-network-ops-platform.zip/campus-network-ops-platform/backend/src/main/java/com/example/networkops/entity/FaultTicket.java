package com.example.networkops.entity;
import jakarta.persistence.*; import lombok.Getter; import lombok.Setter; import java.time.LocalDateTime;
@Entity @Table(name="fault_ticket") @Getter @Setter
public class FaultTicket { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private String ticketNo; private Long userId; private Long areaId; private Long deviceId; private String type; private String title; private String description; private String status; private Integer priority; private Long operatorId; private String solution; private LocalDateTime createdAt; private LocalDateTime updatedAt; }
