package com.example.networkops.repository;
import com.example.networkops.entity.NetworkUser; import org.springframework.data.jpa.repository.JpaRepository; import java.util.Optional;
public interface NetworkUserRepository extends JpaRepository<NetworkUser,Long>{ Optional<NetworkUser> findByUsernameAndPassword(String username,String password); }
