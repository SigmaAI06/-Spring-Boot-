package com.example.networkops.repository;
import com.example.networkops.entity.NetworkArea; import org.springframework.data.jpa.repository.JpaRepository;
public interface NetworkAreaRepository extends JpaRepository<NetworkArea,Long>{}
