package com.example.networkops.repository;
import com.example.networkops.entity.FaultTicket; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface FaultTicketRepository extends JpaRepository<FaultTicket,Long>{ long countByStatus(String status); List<FaultTicket> findTop10ByOrderByCreatedAtDesc(); }
