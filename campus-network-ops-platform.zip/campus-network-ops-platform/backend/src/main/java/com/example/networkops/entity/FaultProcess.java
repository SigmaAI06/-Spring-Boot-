package com.example.networkops.entity;
import jakarta.persistence.*; import lombok.Getter; import lombok.Setter; import java.time.LocalDateTime;
@Entity @Table(name="fault_process") @Getter @Setter
public class FaultProcess { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private Long ticketId; private Long operatorId; private String action; private String content; private LocalDateTime createdAt; }
