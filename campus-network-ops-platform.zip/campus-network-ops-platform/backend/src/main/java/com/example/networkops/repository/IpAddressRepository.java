package com.example.networkops.repository;
import com.example.networkops.entity.IpAddress; import org.springframework.data.jpa.repository.JpaRepository;
public interface IpAddressRepository extends JpaRepository<IpAddress,Long>{}
