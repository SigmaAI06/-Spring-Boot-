package com.example.networkops.dto; public record LoginRequest(String username,String password){}
