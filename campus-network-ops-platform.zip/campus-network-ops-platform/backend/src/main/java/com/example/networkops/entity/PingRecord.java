package com.example.networkops.entity;
import jakarta.persistence.*; import lombok.Getter; import lombok.Setter; import java.time.LocalDateTime;
@Entity @Table(name="ping_record") @Getter @Setter
public class PingRecord { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private String targetIp; private String result; private Integer latencyMs; private String message; private LocalDateTime createdAt; }
