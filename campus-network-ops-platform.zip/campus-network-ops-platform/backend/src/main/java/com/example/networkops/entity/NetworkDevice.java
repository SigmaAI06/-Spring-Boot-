package com.example.networkops.entity;
import jakarta.persistence.*; import lombok.Getter; import lombok.Setter;
@Entity @Table(name="network_device") @Getter @Setter
public class NetworkDevice { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private String deviceCode; private String name; private String type; private String ipAddress; private String macAddress; private String status; private String location; private Long areaId; }
