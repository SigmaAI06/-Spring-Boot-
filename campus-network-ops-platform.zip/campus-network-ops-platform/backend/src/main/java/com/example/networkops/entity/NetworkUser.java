package com.example.networkops.entity;
import jakarta.persistence.*; import lombok.Getter; import lombok.Setter;
@Entity @Table(name="network_user") @Getter @Setter
public class NetworkUser { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private String username; private String password; private String role; private String realName; private String phone; private Integer enabled; }
