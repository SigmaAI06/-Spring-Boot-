package com.example.networkops.dto; public record PingRequest(String targetIp){}
