package com.example.networkops.repository;
import com.example.networkops.entity.FaultProcess; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface FaultProcessRepository extends JpaRepository<FaultProcess,Long>{ List<FaultProcess> findByTicketIdOrderByCreatedAtAsc(Long ticketId); }
