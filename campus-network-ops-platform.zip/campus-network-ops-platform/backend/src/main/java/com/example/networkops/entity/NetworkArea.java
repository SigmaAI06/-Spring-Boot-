package com.example.networkops.entity;
import jakarta.persistence.*; import lombok.Getter; import lombok.Setter;
@Entity @Table(name="network_area") @Getter @Setter
public class NetworkArea { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private String name; private String building; private String subnet; private String description; }
