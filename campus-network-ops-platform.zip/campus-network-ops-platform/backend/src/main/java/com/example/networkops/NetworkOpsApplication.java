package com.example.networkops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetworkOpsApplication {
    public static void main(String[] args) {
        SpringApplication.run(NetworkOpsApplication.class, args);
    }
}
