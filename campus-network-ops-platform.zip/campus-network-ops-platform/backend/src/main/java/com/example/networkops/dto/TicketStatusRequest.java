package com.example.networkops.dto; public record TicketStatusRequest(String status,Long operatorId,String solution,String action,String content){}
