package com.example.networkops.repository;
import com.example.networkops.entity.PingRecord; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface PingRecordRepository extends JpaRepository<PingRecord,Long>{ List<PingRecord> findTop20ByOrderByCreatedAtDesc(); }
