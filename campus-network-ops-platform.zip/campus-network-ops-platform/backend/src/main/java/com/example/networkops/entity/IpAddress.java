package com.example.networkops.entity;
import jakarta.persistence.*; import lombok.Getter; import lombok.Setter;
@Entity @Table(name="ip_address") @Getter @Setter
public class IpAddress { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id; private String ip; private String subnet; private String status; private String owner; private String macAddress; private String remark; }
