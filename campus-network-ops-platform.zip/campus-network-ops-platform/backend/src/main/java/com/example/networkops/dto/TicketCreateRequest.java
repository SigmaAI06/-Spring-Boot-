package com.example.networkops.dto; public record TicketCreateRequest(Long userId,Long areaId,Long deviceId,String type,String title,String description,Integer priority){}
